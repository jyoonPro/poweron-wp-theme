<?php get_header();?>

<section class="section p-404">
    <div class="container">
      <div class="content has-text-centered">
        <h1>404</h1>
        <h3>Not Found</h3>
        <h4>요청하신 페이지를 찾을 수 없습니다</h4>
      </div>
    </div>
  </section>

<?php get_footer();?>